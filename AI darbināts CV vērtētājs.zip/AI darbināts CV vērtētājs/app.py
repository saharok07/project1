#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI Darbināts CV Vērtētājs - Web Aplikācija
Flask aplikācija ar modernu interfeisu CV analīzei
"""

from flask import Flask, render_template, request, jsonify, send_from_directory
import os
import json
import google.generativeai as genai
from dotenv import load_dotenv
from pathlib import Path

# Inicializē Flask aplikāciju
app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here-change-in-production'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Ielādē vides mainīgos
load_dotenv()

# Direktorijas
BASE_DIR = Path(__file__).parent
INPUT_DIR = BASE_DIR / "sample_inputs"
OUTPUT_DIR = BASE_DIR / "outputs"
HISTORY_DIR = BASE_DIR / "history"

# Izveido nepieciešamās direktorijas
OUTPUT_DIR.mkdir(exist_ok=True)
HISTORY_DIR.mkdir(exist_ok=True)

HISTORY_FILE = HISTORY_DIR / "analysis_history.json"

def configure_gemini():
    """Konfigurē Gemini API"""
    api_key = os.getenv('GEMINI_API_KEY')
    
    if not api_key:
        raise ValueError("GEMINI_API_KEY nav atrasts .env failā!")
    
    genai.configure(api_key=api_key)
    return genai.GenerativeModel(
        model_name="gemini-2.0-flash-exp",
        generation_config={
            "temperature": 0.2,
            "top_p": 0.95,
            "top_k": 40,
            "max_output_tokens": 8192,
        }
    )

def load_file(filepath):
    """Nolasa failu"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return f.read()
    except Exception as e:
        print(f"Kļūda nolasot failu {filepath}: {e}")
        return None

def load_prompt_template():
    """Nolasa prompt veidni"""
    prompt_file = BASE_DIR / "prompt.md"
    template = load_file(prompt_file)
    if not template:
        return get_default_prompt()
    return template

def get_default_prompt():
    """Noklusējuma prompt"""
    return """Jūs esat profesionāls HR konsultants. Analizējiet kandidāta CV un salīdziniet to ar darba aprakstu.

Darba Apraksts:
{jd_text}

Kandidāta CV:
{cv_text}

Atbildiet TIKAI ar JSON formātu:
{{
  "match_score": <0-100>,
  "summary": "<īss apraksts latviski>",
  "strengths": ["<stiprā puse 1>", "<stiprā puse 2>", ...],
  "missing_requirements": ["<trūkstošā prasība 1>", ...],
  "verdict": "<strong match | possible match | not a match>"
}}
"""

def save_to_history(jd_text, results):
    """Saglabā analīzes rezultātus vēsturē"""
    from datetime import datetime
    
    # Nolasa esošo vēsturi
    history = []
    if HISTORY_FILE.exists():
        try:
            with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
                history = json.load(f)
        except:
            history = []
    
    # Ģenerējam unikālu ID šai analīzes sesijai
    session_id = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    # Saglabājam pilnas rezultātu kopijas ar unikāliem ID
    saved_results = []
    for idx, result in enumerate(results):
        if 'error' not in result:
            # Izveidojam rezultāta kopiju ar unikālu ID
            result_copy = result.copy()
            unique_cv_id = f"{session_id}_cv{idx+1}"
            result_copy['cv_id'] = unique_cv_id
            result_copy['original_cv_id'] = result.get('cv_id', f'cv{idx+1}')
            
            # Saglabājam pilnu rezultāta kopiju atsevišķā failā
            history_result_path = OUTPUT_DIR / f"{unique_cv_id}.json"
            with open(history_result_path, 'w', encoding='utf-8') as f:
                json.dump(result_copy, f, ensure_ascii=False, indent=2)
            
            saved_results.append(result_copy)
        else:
            saved_results.append(result)
    
    # Pievieno jaunu ierakstu
    entry = {
        'timestamp': datetime.now().isoformat(),
        'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'session_id': session_id,
        'job_description': jd_text[:200] + '...' if len(jd_text) > 200 else jd_text,
        'results': saved_results,
        'total_cvs': len(saved_results),
        'avg_score': sum(r.get('match_score', 0) for r in saved_results if 'match_score' in r) / len(saved_results) if saved_results else 0
    }
    
    history.insert(0, entry)  # Jaunākais pirmais
    
    # Saglabā tikai pēdējos 50 ierakstus
    history = history[:50]
    
    with open(HISTORY_FILE, 'w', encoding='utf-8') as f:
        json.dump(history, f, ensure_ascii=False, indent=2)

def get_history():
    """Atgriež vēsturi"""
    if not HISTORY_FILE.exists():
        return []
    
    try:
        with open(HISTORY_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except:
        return []

def analyze_cv_with_gemini(jd_text, cv_text):
    """Analizē CV ar Gemini"""
    try:
        model = configure_gemini()
        prompt_template = load_prompt_template()
        prompt = prompt_template.format(jd_text=jd_text, cv_text=cv_text)
        
        response = model.generate_content(prompt)
        response_text = response.text.strip()
        
        # Noņem markdown code blocks
        if response_text.startswith("```json"):
            response_text = response_text[7:]
        if response_text.startswith("```"):
            response_text = response_text[3:]
        if response_text.endswith("```"):
            response_text = response_text[:-3]
        
        response_text = response_text.strip()
        result = json.loads(response_text)
        
        return result
    except Exception as e:
        print(f"Kļūda analizējot CV: {e}")
        return None

@app.route('/')
def index():
    """Sākumlapa"""
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    """Analizē visus CV failus"""
    try:
        print("\n" + "="*70)
        print("🚀 SĀKAS CV ANALĪZE")
        print("="*70)
        
        # Nolasa JD no faila (nevis no request body)
        jd_path = INPUT_DIR / "jd.txt"
        jd_text = load_file(jd_path)
        
        if not jd_text:
            print("❌ Darba apraksts nav atrasts!")
            return jsonify({'error': 'Darba apraksts (JD) nav atrasts sample_inputs/jd.txt'}), 400
        
        print(f"✅ Darba apraksts nolasīts: {len(jd_text)} simboli")
        results = []
        
        # Analizē katru CV
        for i in range(1, 4):
            print(f"\n📄 Analizē CV #{i}...")
            cv_path = INPUT_DIR / f"cv{i}.txt"
            cv_text = load_file(cv_path)
            
            if not cv_text:
                print(f"❌ CV{i} fails nav atrasts!")
                results.append({
                    'cv_name': f'Kandidāts {i}',
                    'error': 'CV fails nav atrasts'
                })
                continue
            
            print(f"✅ CV{i} nolasīts: {len(cv_text)} simboli")
            
            # Analizē ar Gemini
            result = analyze_cv_with_gemini(jd_text, cv_text)
            
            if result:
                result['cv_name'] = f'Kandidāts {i}'
                result['cv_id'] = f'cv{i}'
                
                print(f"✅ CV{i} analizēts! Match score: {result.get('match_score', 'N/A')}")
                
                # Saglabā JSON
                json_path = OUTPUT_DIR / f"cv{i}.json"
                with open(json_path, 'w', encoding='utf-8') as f:
                    json.dump(result, f, ensure_ascii=False, indent=2)
                
                results.append(result)
            else:
                print(f"❌ Kļūda analizējot CV{i}")
                results.append({
                    'cv_name': f'Kandidāts {i}',
                    'error': 'Kļūda analizējot CV'
                })
        
        # Saglabā vēsturē
        save_to_history(jd_text, results)
        
        print(f"\n✅ PABEIGTS! Kopā rezultāti: {len(results)}")
        print("="*70 + "\n")
        
        return jsonify({'results': results})
    
    except Exception as e:
        print(f"\n❌ KRITISKA KĻŪDA: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/history')
def api_history():
    """API galapunkts vēstures iegūšanai"""
    try:
        history = get_history()
        return jsonify(history)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/cv/<cv_id>')
def cv_detail(cv_id):
    """Detalizēts CV pārskats"""
    json_path = OUTPUT_DIR / f"{cv_id}.json"
    
    if not json_path.exists():
        return render_template('error.html', 
                             error='CV novērtējums nav atrasts!',
                             message='Lūdzu, vispirms veiciet analīzi.')
    
    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            result = json.load(f)
        
        return render_template('cv_detail.html', result=result, cv_id=cv_id)
    except Exception as e:
        return render_template('error.html', 
                             error='Kļūda ielādējot datus',
                             message=str(e))

@app.route('/download/<cv_id>/<format>')
def download(cv_id, format):
    """Lejupielādē pārskatu"""
    if format == 'json':
        return send_from_directory(OUTPUT_DIR, f"{cv_id}.json", as_attachment=True)
    elif format == 'md':
        return send_from_directory(OUTPUT_DIR, f"{cv_id}_report.md", as_attachment=True)
    elif format == 'html':
        return send_from_directory(OUTPUT_DIR, f"{cv_id}_report.html", as_attachment=True)
    else:
        return "Invalid format", 400

@app.route('/api/status')
def status():
    """API statusa pārbaude"""
    try:
        configure_gemini()
        return jsonify({
            'status': 'ok',
            'api_configured': True,
            'message': 'Gemini API ir konfigurēts un gatavs darbam'
        })
    except Exception as e:
        return jsonify({
            'status': 'error',
            'api_configured': False,
            'message': str(e)
        }), 500

@app.errorhandler(404)
def not_found(e):
    """404 kļūdas apstrādātājs"""
    return render_template('error.html', 
                         error='Lapa nav atrasta',
                         message='Meklētā lapa neeksistē.'), 404

@app.errorhandler(500)
def internal_error(e):
    """500 kļūdas apstrādātājs"""
    return render_template('error.html', 
                         error='Servera kļūda',
                         message='Radās neparedzēta kļūda. Lūdzu, mēģiniet vēlreiz.'), 500

if __name__ == '__main__':
    print("\n" + "="*70)
    print("  🚀 AI CV VĒRTĒTĀJS - WEB APLIKĀCIJA")
    print("  Powered by Google Gemini Flash 2.5")
    print("="*70)
    print("\n  📡 Serveris startē: http://localhost:5000")
    print("  📋 Atveriet pārlūkprogrammu un dodieties uz augstāk norādīto adresi")
    print("\n  ⏹️  Nospiediet Ctrl+C lai apturētu serveri")
    print("="*70 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
