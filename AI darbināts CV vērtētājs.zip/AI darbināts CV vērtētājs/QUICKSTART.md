# ⚡ ĀTRĀ SĀKŠANA

Šī pamācība palīdzēs jums sākt darbu ar AI CV Vērtētāju 5 minūtēs!

## 📋 Satura Rādītājs

1. [Priekšnosacījumi](#priekšnosacījumi)
2. [Instalācija](#instalācija)
3. [Konfigurācija](#konfigurācija)
4. [Pirmā Palaišana](#pirmā-palaišana)
5. [Problēmu Risināšana](#problēmu-risināšana)

---

## 🔧 Priekšnosacījumi

Pirms sākšanas, pārliecinieties, ka jums ir:

### 1. Python 3.8+
```bash
python --version
```

Ja Python nav instalēts:
- Lejupielādējiet no: https://www.python.org/downloads/
- ✅ Atzīmējiet "Add Python to PATH" instalācijas laikā!

### 2. Gemini API Atslēga
- Dodieties uz: https://makersuite.google.com/app/apikey
- Reģistrējieties vai ielogojieties
- Izveidojiet jaunu API atslēgu
- Saglabājiet to drošā vietā

### 3. Interneta Savienojums
- Nepieciešams API izsaukumiem

---

## 📦 Instalācija

### Variants 1: Automātiskā Instalācija (Ieteicams)

**Windows:**
1. Dubultklikšķis uz `START.bat`
2. Programma automātiski instalēs visas nepieciešamās bibliotēkas
3. Uzgaidiet instalācijas pabeigšanu

### Variants 2: Manuālā Instalācija

1. **Atveriet termināli/komandrindu**
   - Windows: `Win + R` → `cmd`
   - Pārejiet uz projekta mapi: `cd ceļš\uz\projektu`

2. **Izveidojiet virtuālo vidi (ieteicams)**
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```

3. **Instalējiet bibliotēkas**
   ```bash
   pip install -r requirements.txt
   ```

---

## ⚙️ Konfigurācija

### 1. Izveidojiet .env Failu

Ja `.env` fails neeksistē:

1. Pārdēvējiet `.env.example` uz `.env`
2. Atveriet ar teksta redaktoru (Notepad, VS Code, utt.)
3. Aizstājiet `jūsu_api_atslēga_šeit` ar jūsu Gemini API atslēgu:

```env
GEMINI_API_KEY=AIzaSyCJ6PuUXjbULxAR6hXnmoid0FbGmxpPMtI
```

4. Saglabājiet failu

### 2. Pārbaudiet Ievaddatus (Neobligāti)

Projekts jau satur paraugu datus `sample_inputs/` mapē:
- `jd.txt` - Darba apraksts
- `cv1.txt`, `cv2.txt`, `cv3.txt` - Kandidātu CV

Varat aizstāt tos ar saviem datiem, saglabājot failu nosaukumus!

---

## 🚀 Pirmā Palaišana

### Izvēlieties Režīmu:

#### A) 🌐 Web Aplikācija (Ieteicams)

**Vienkāršākais veids:**
1. Dubultklikšķis uz `START.bat`
2. Uzgaidiet, kamēr serveris startējas
3. Atveriet pārlūkprogrammu
4. Dodieties uz: **http://localhost:5000**
5. Noklikšķiniet "Analizēt Visus CV"

**Vai caur komandrindu:**
```bash
python app.py
```

#### B) 💻 Konsoles Versija

**Vienkāršākais veids:**
1. Dubultklikšķis uz `KONSOLE.bat`
2. Programma automātiski apstrādās visus CV
3. Rezultāti tiks saglabāti `outputs/` mapē

**Vai caur komandrindu:**
```bash
python main.py
```

---

## 📊 Rezultātu Atrašana

Pēc analīzes pabeigšanas, rezultāti būs pieejami `outputs/` mapē:

```
outputs/
├── cv1.json           ← JSON formāts (strukturēti dati)
├── cv1_report.md      ← Markdown (lasāms teksts)
├── cv1_report.html    ← HTML (skaists pārskats)
├── cv2.json
├── cv2_report.md
├── cv2_report.html
└── ...
```

### Kā Apskatīt Rezultātus:

- **JSON**: Atveriet ar teksta redaktoru vai VS Code
- **Markdown**: Atveriet ar Markdown viewer vai VS Code
- **HTML**: Dubultklikšķis → atveras pārlūkprogrammā 🌐

---

## 🎯 Tipiskais Workflow

1. **Sagatavot datus**
   - Pārbaudiet, vai `sample_inputs/jd.txt` un `cv*.txt` ir pareizi

2. **Palaist analīzi**
   - Web: `START.bat` → atveriet http://localhost:5000
   - CLI: `KONSOLE.bat`

3. **Apskatīt rezultātus**
   - Web interfeisā: noklikšķiniet "Skatīt Detaļas"
   - Vai atveriet HTML failus no `outputs/`

4. **Eksportēt**
   - Lejupielādējiet JSON/MD/HTML pārskatus
   - Kopējiet rezultātus citām aplikācijām

---

## ❓ Problēmu Risināšana

### "Python nav atrasts"
✅ **Risinājums:**
- Instalējiet Python no python.org
- Restartējiet datoru pēc instalācijas
- Pārbaudiet: `python --version`

### "GEMINI_API_KEY nav atrasts"
✅ **Risinājums:**
- Izveidojiet `.env` failu
- Pievienojiet API atslēgu
- Pārliecinieties, ka nav liekas atstarpes

### "Fails nav atrasts"
✅ **Risinājums:**
- Pārbaudiet, vai esat projekta direktorijā
- Pārbaudiet failu nosaukumus (jābūt precīziem!)

### "Module not found"
✅ **Risinājums:**
```bash
pip install -r requirements.txt
```

### API kļūda / 429 Error
✅ **Risinājums:**
- Pārbaudiet interneta savienojumu
- Pārbaudiet vai API atslēga ir derīga
- Uzgaidiet 1 minūti (rate limit)

### Web aplikācija neatveras
✅ **Risinājums:**
- Pārbaudiet vai ports 5000 nav aizņemts
- Mēģiniet aizvērt citas programmas
- Restartējiet datoru

---

## 📞 Papildu Palīdzība

Ja rodas problēmas:

1. **Lasiet pilno instrukciju**: `INSTRUKCIJA.md`
2. **Pārbaudiet log failus**: konsoles izvade
3. **Pārbaudiet API statusu**: http://localhost:5000/api/status (ja serveris darbojas)

---

## 🎉 Gatavs Darbam!

Tagad jums ir viss nepieciešamais, lai sāktu izmantot AI CV Vērtētāju!

**Lai veiksmīgi!** 🚀

---

*Izveidots ar ❤️ izmantojot Google Gemini Flash 2.5*
