# 📖 PILNA INSTRUKCIJA - AI CV Vērtētājs

Šī ir detalizēta lietošanas instrukcija AI CV Vērtētājam - profesionālam rīkam kandidātu CV analīzei, izmantojot Google Gemini Flash 2.5 mākslīgo intelektu.

---

## 📑 Satura Rādītājs

1. [Ievads](#ievads)
2. [Sistēmas Prasības](#sistēmas-prasības)
3. [Instalācijas Process](#instalācijas-process)
4. [Projekta Struktūra](#projekta-struktūra)
5. [Konfigurācija](#konfigurācija)
6. [Datu Sagatavošana](#datu-sagatavošana)
7. [Lietošana](#lietošana)
8. [Rezultātu Interpretācija](#rezultātu-interpretācija)
9. [Papildu Funkcijas](#papildu-funkcijas)
10. [Problēmu Risināšana](#problēmu-risināšana)
11. [Bieži Uzdotie Jautājumi](#bieži-uzdotie-jautājumi)
12. [Labākās Prakses](#labākās-prakses)

---

## 📘 Ievads

### Kas ir AI CV Vērtētājs?

AI CV Vērtētājs ir profesionāla Python aplikācija, kas:
- Automātiski salīdzina kandidātu CV ar darba aprakstu (JD)
- Izmanto Google Gemini Flash 2.5 AI modeli precīzai analīzei
- Ģenerē detalizētus pārskatus vairākos formātos (JSON, Markdown, HTML)
- Sniedz objektīvu vērtējumu (0-100 punkti)
- Identificē kandidāta stiprās puses un trūkumus
- Dod ieteikumu par tālāko rīcību

### Galvenās Priekšrocības

✅ **Ātri** - Analizē visus CV dažās sekundēs  
✅ **Objektīvi** - AI novērš cilvēciskos aizspriedumus  
✅ **Detalizēti** - Dziļa analīze ar konkrētiem piemēriem  
✅ **Profesionāli** - Gatavi pārskati prezentācijai  
✅ **Ērti** - Gan CLI, gan Web interfeiss  

---

## 💻 Sistēmas Prasības

### Minimālās Prasības

| Komponente | Prasība |
|------------|---------|
| **OS** | Windows 10/11, macOS 10.15+, Linux (Ubuntu 20.04+) |
| **Python** | 3.8 vai jaunāks |
| **RAM** | 2 GB brīvās |
| **Disk Space** | 500 MB |
| **Internet** | Stabils savienojums (API calls) |

### Ieteicamās Prasības

- **Python 3.10+** - Labāka veiktspēja
- **4 GB RAM** - Smooth experience
- **SSD** - Ātrāka datu apstrāde

### Nepieciešamie Rīki

1. **Python Interpreter**
   - Lejupielāde: https://www.python.org/downloads/
   - Instalācijas laikā: ✅ "Add Python to PATH"

2. **Gemini API Atslēga**
   - Reģistrācija: https://makersuite.google.com/
   - Izveido jaunu API key
   - Bezmaksas līmenis: 60 requests/minute

3. **Teksta Redaktors** (ieteicams)
   - VS Code: https://code.visualstudio.com/
   - Notepad++ : https://notepad-plus-plus.org/
   - Vai jebkurš cits

---

## 🔧 Instalācijas Process

### 1. Lejupielādēt Projektu

**Variants A: Git**
```bash
git clone <repository-url>
cd AI_CV_Vertejums
```

**Variants B: ZIP arhīvs**
1. Lejupielādējiet projektu kā ZIP
2. Izpakojiet uz izvēlētu vietu
3. Atveriet mapi terminālī

### 2. Izveidot Virtuālo Vidi (Ieteicams)

**Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

**macOS/Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

Redzēsiet `(venv)` pirms komandas prompt - tas nozīmē, ka vide ir aktivizēta.

### 3. Instalēt Atkarības

```bash
pip install -r requirements.txt
```

Tiks instalētas šādas bibliotēkas:
- `google-generativeai` - Gemini API
- `python-dotenv` - Vides mainīgo pārvaldība
- `Flask` - Web aplikācija
- `Markdown` - Markdown ģenerēšana
- `Jinja2` - HTML templating

### 4. Pārbaudīt Instalāciju

```bash
python --version
pip list
```

Jāredz visas instalētās paketes.

---

## 📂 Projekta Struktūra

```
AI_CV_Vertejums/
│
├── 📄 main.py                 # Konsoles versijas galvenais skripts
├── 🌐 app.py                  # Flask web aplikācija
├── 📝 prompt.md               # Gemini AI prompt veidne
├── 📋 requirements.txt        # Python atkarības
├── 🔧 .env                    # API konfigurācija (izveidojams)
├── 📖 README.md               # Projekta dokumentācija
├── 🚀 QUICKSTART.md           # Ātrā sākšanas pamācība
├── 📚 INSTRUKCIJA.md          # Šis fails - pilna instrukcija
├── ⚖️ LICENSE                 # MIT licence
├── 🗑️ .gitignore              # Git ignore fails
│
├── ✅ KONSOLE.bat             # Windows batch - CLI palaišana
├── 🌐 START.bat               # Windows batch - Web palaišana
│
├── 📂 sample_inputs/          # Ievaddatu mape
│   ├── jd.txt                # Darba apraksts (Job Description)
│   ├── cv1.txt               # Kandidāts 1 CV
│   ├── cv2.txt               # Kandidāts 2 CV
│   └── cv3.txt               # Kandidāts 3 CV
│
├── 📂 outputs/                # Rezultātu mape
│   ├── cv1.json              # JSON rezultāts 1
│   ├── cv1_report.md         # Markdown pārskats 1
│   ├── cv1_report.html       # HTML pārskats 1
│   └── ...                   # Citi rezultāti
│
├── 📂 templates/              # HTML veidnes (Flask)
│   ├── base.html             # Bāzes template
│   ├── index.html            # Galvenā lapa
│   ├── cv_detail.html        # CV detaļu lapa
│   └── error.html            # Kļūdu lapa
│
└── 📂 static/                 # Statiskie faili
    ├── css/
    │   └── styles.css        # Galvenie stili
    └── js/
        └── main.js           # JavaScript funkcionalitāte
```

---

## ⚙️ Konfigurācija

### .env Faila Izveide

1. **Pārdēvējiet failu:**
   - Windows: `copy .env.example .env`
   - macOS/Linux: `cp .env.example .env`

2. **Rediģējiet .env failu:**

```env
# Google Gemini API Configuration
GEMINI_API_KEY=jūsu_īstā_api_atslēga

# Flask Configuration (optional)
FLASK_ENV=development
FLASK_DEBUG=True
FLASK_PORT=5000
```

3. **Aizvietojiet API atslēgu:**
   - Dodieties uz https://makersuite.google.com/app/apikey
   - Izveidojiet jaunu atslēgu
   - Kopējiet un ielīmējiet `.env` failā

### Gemini Model Iestatījumi

Failā `main.py` un `app.py` var mainīt model parametrus:

```python
generation_config = {
    "temperature": 0.2,          # 0.0-1.0, zemāks = precīzāks
    "top_p": 0.95,               # Nucleus sampling
    "top_k": 40,                 # Top-k sampling
    "max_output_tokens": 8192,   # Maksimālais atbildes garums
}
```

**Temperature Izskaidrojums:**
- `0.0-0.3` - Augsta precizitāte, konsekventas atbildes (✅ ieteicams)
- `0.4-0.7` - Balansēts
- `0.8-1.0` - Radošs, bet neprecīzs

---

## 📝 Datu Sagatavošana

### Darba Apraksta (JD) Faila Formāts

Fails: `sample_inputs/jd.txt`

**Saturam jābūt:**
- Teksta formātā (UTF-8 encoding)
- Skaidri strukturētam
- Saturošam:
  - Pozīcijas nosaukums
  - Galvenās atbildības
  - Obligātās prasības
  - Vēlamās prasības
  - Tehniskais steks

**Piemērs:**
```
POZĪCIJA: PYTHON BACKEND DEVELOPER

ATBILDĪBAS:
• Backend sistēmu izstrāde ar Django/Flask
• RESTful API projektēšana
• Datubāzu optimizācija
...

OBLIGĀTĀS PRASĪBAS:
• 3+ gadu pieredze ar Python
• Django vai Flask zināšanas
...
```

### CV Failu Formāts

Faili: `sample_inputs/cv1.txt`, `cv2.txt`, `cv3.txt`

**Saturam jābūt:**
- Teksta formātā (UTF-8)
- Strukturētam (sections ar headers)
- Saturošam:
  - Personīgā informācija
  - Darba pieredze
  - Izglītība
  - Tehniskās prasmes
  - Projekti (optional)

**Tips:** Varat izmantot gatavos paraugu CV kā veidni!

### Failu Nomainīšana

Lai analizētu savus CV:

1. Sagatavojiet CV teksta formātā
2. Pārdēvējiet CV failus uz: `cv1.txt`, `cv2.txt`, `cv3.txt`
3. Ievietojiet `sample_inputs/` mapē
4. Aizstājiet esošos failus

**Svarīgi:** Saglabājiet failu nosaukumus nemainītus!

---

## 🚀 Lietošana

### A) Konsoles Versija (CLI)

**Ātrā Metode:**
```bash
# Windows
KONSOLE.bat

# macOS/Linux
python3 main.py
```

**Process:**
1. Programma nolasa `jd.txt`
2. Cikliski apstrādā katru CV (`cv1.txt`, `cv2.txt`, `cv3.txt`)
3. Katram CV:
   - Izsauc Gemini API
   - Saņem JSON atbildi
   - Ģenerē 3 failus: `.json`, `_report.md`, `_report.html`
4. Saglabā visus rezultātus `outputs/` mapē

**Izvade Konsolē:**
```
════════════════════════════════════════════════════════════════
  🤖 AI DARBINĀTS CV VĒRTĒTĀJS
  Powered by Google Gemini Flash 2.5
════════════════════════════════════════════════════════════════

📖 Nolasa darba aprakstu...
✅ Darba apraksts nolasīts (2456 simboli)

🔧 Konfigurē Gemini API...
✅ Gemini Flash 2.5 gatavs darbam!

──────────────────────────────────────────────────────────────
  Apstrādā: Kandidāts 1
──────────────────────────────────────────────────────────────

📄 CV nolasīts (3821 simboli)
📄 Analizē: Kandidāts 1...
✅ Analīze pabeigta!
💾 JSON saglabāts: outputs/cv1.json
📝 Markdown pārskats saglabāts: outputs/cv1_report.md
🌐 HTML pārskats saglabāts: outputs/cv1_report.html

✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨
  Kandidāts 1 analīze pabeigta veiksmīgi!
✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨

[Turpinās ar cv2 un cv3...]

═════════════════════════════════════════════════════════════
  ✅ VISI CV IR VEIKSMĪGI APSTRĀDĀTI!
═════════════════════════════════════════════════════════════

📁 Rezultāti saglabāti: outputs/
```

### B) Web Aplikācija (Ieteicams)

**Ātrā Metode:**
```bash
# Windows
START.bat

# macOS/Linux
python3 app.py
```

**Servera Startēšana:**
```
════════════════════════════════════════════════════════════════
  🚀 AI CV VĒRTĒTĀJS - WEB APLIKĀCIJA
  Powered by Google Gemini Flash 2.5
════════════════════════════════════════════════════════════════

  📡 Serveris startē: http://localhost:5000
  📋 Atveriet pārlūkprogrammu un dodieties uz augstāk norādīto adresi

  ⏹️  Nospiediet Ctrl+C lai apturētu serveri
════════════════════════════════════════════════════════════════
```

**Lietošana Pārlūkprogrammā:**

1. **Atveriet:** http://localhost:5000
2. **Galvenā lapa:**
   - Redzēsiet hero section ar intro
   - "Kā tas darbojas" sekcija ar soļiem
   - "Sākt Analīzi" poga

3. **Analīzes Sākšana:**
   - Noklikšķiniet "Analizēt Visus CV"
   - Redzēsiet loading animāciju
   - AI apstrādā katru CV (~10-30 sek.)

4. **Rezultātu Apskatīšana:**
   - Parādās cards ar katru kandidātu
   - Redzēsiet match score (0-100)
   - Verdict badge (strong/possible/not a match)
   - "Skatīt Detaļas" poga

5. **Detalizēts Pārskats:**
   - Noklikšķiniet "Skatīt Detaļas"
   - Jauna lapa ar pilnu analīzi:
     - Vizuāls progress circle
     - Kopsavilkums
     - Stiprās puses (saraksts)
     - Trūkstošās prasības (saraksts)
     - Ieteikums (rekomendācija)
   - Lejupielādes pogas (JSON/MD/HTML)

---

## 📊 Rezultātu Interpretācija

### JSON Struktūra

```json
{
  "match_score": 85,
  "summary": "Kandidāts labi atbilst pozīcijai...",
  "strengths": [
    "4+ gadu pieredze ar Python un Django",
    "Spēcīgas datubāzu zināšanas",
    ...
  ],
  "missing_requirements": [
    "Nav pieredzes ar Kubernetes",
    ...
  ],
  "verdict": "strong match"
}
```

### Match Score Skaidrojums

| Score | Līmenis | Nozīme | Ieteikums |
|-------|---------|--------|-----------|
| **80-100** | 🌟 AUGSTS | Lieliska atbilstība | Aiciniet uz interviju |
| **50-79** | ⚡ VIDĒJS | Daļēja atbilstība | Apsvērt kandidatūru |
| **0-49** | ⚠️ ZEMS | Vāja atbilstība | Meklēt citus kandidātus |

### Verdict Vērtības

- **"strong match"** - Kandidāts ir piemērots, atbilst lielākajai daļai prasību
- **"possible match"** - Kandidāts ir iespējams, bet vajag papildu izvērtēšanu
- **"not a match"** - Kandidāts neatbilst galvenajām prasībām

### Markdown Pārskats

- Strukturēts, lasāms formāts
- Ideāls iekšējai dokumentācijai
- Viegli rediģējams
- Viegli konvertējams uz PDF

### HTML Pārskats

- Profesionāls, skaists dizains
- Gatavs prezentācijai
- Printējams
- Viegli dalāms ar kolēģiem

---

## 🎨 Papildu Funkcijas

### Prompt Pielāgošana

Rediģējiet `prompt.md`, lai mainītu AI uzvedību:

```markdown
## Svarīgi Norādījumi

- Vērtējiet arī soft skills
- Ņemiet vērā karieras progresiju
- Uzsveriet leadership pieredzi
...
```

### API Statusa Pārbaude

Web aplikācijā:
```
GET http://localhost:5000/api/status
```

Atbilde:
```json
{
  "status": "ok",
  "api_configured": true,
  "message": "Gemini API ir konfigurēts un gatavs darbam"
}
```

### Batch Processing

Lai analizētu vairāk nekā 3 CV, pievienojiet:
- `cv4.txt`, `cv5.txt`, ...
- Modificējiet `main.py` cv_files sarakstu

### Eksportēšana

Web aplikācijā - "Lejupielādēt Pārskatu":
- JSON - programmatiskai apstrādei
- Markdown - dokumentācijai
- HTML - prezentācijai

---

## 🐛 Problēmu Risināšana

### 1. "Python nav atrasts"

**Simptoms:**
```
'python' is not recognized as an internal or external command
```

**Risinājums:**
1. Instalējiet Python no python.org
2. Reinstalējiet ar "Add to PATH" opciju
3. Restartējiet termināli/datoru
4. Pārbaudiet: `python --version`

### 2. "GEMINI_API_KEY nav atrasts"

**Simptoms:**
```
❌ KĻŪDA: GEMINI_API_KEY nav atrasts .env failā!
```

**Risinājums:**
1. Izveidojiet `.env` failu projekta saknē
2. Pievienojiet: `GEMINI_API_KEY=jūsu_atslēga`
3. Pārbaudiet, vai nav liekas atstarpes
4. Saglabājiet UTF-8 encoding

### 3. "Module not found"

**Simptoms:**
```
ModuleNotFoundError: No module named 'google.generativeai'
```

**Risinājums:**
```bash
pip install -r requirements.txt
# Vai
pip install google-generativeai python-dotenv Flask
```

### 4. API Kļūdas

**429 - Too Many Requests:**
- Pārāk daudz pieprasījumu
- Uzgaidiet 1 minūti
- Free tier: 60 req/min

**401 - Unauthorized:**
- Nederīga API atslēga
- Pārbaudiet `.env` failu
- Ģenerējiet jaunu atslēgu

**503 - Service Unavailable:**
- Gemini API īslaicīgi nepieejams
- Mēģiniet vēlāk

### 5. Encoding Problēmas

**Simptoms:** Nepareizi latviskie burti

**Risinājums:**
- Saglabājiet visus `.txt` failus ar UTF-8 encoding
- Notepad++: Encoding → UTF-8
- VS Code: Apakšējā labajā stūrī izvēlieties UTF-8

### 6. Web Aplikācija Nestartējas

**Simptoms:**
```
Address already in use
```

**Risinājums:**
- Ports 5000 jau aizņemts
- Mainiet `app.py`: `port=5001`
- Vai apturiet citu aplikāciju uz porta 5000

---

## ❓ Bieži Uzdotie Jautājumi

### Vai es varu izmantot citus AI modeļus?

Jā! Mainiet `main.py` un `app.py`:
```python
model_name="gemini-1.5-pro"  # Vai cits modelis
```

### Cik maksā Gemini API?

- Free tier: 60 requests/minute
- Šim projektam pietiek ar free tier
- Detaļas: https://ai.google.dev/pricing

### Vai CV jābūt angļu valodā?

Nē! Gemini atbalsta latviešu valodu.
CV un JD var būt latviski, angliski vai jaukti.

### Vai varu analizēt PDF CV?

Pašlaik tikai `.txt` faili.
Konvertējiet PDF → TXT:
- Online: pdftotext.com
- Software: Adobe Acrobat

### Vai rezultāti ir pilnīgi precīzi?

AI ir ļoti labs, bet ne 100% precīzs.
Izmantojiet rezultātus kā palīglīdzekli, ne galīgo lēmumu.

### Vai varu izmantot komerciāliem nolūkiem?

Jā, projekts ir MIT licencē - bezmaksas izmantošanai.

---

## 💡 Labākās Prakses

### 1. CV Sagatavošana

✅ **DO:**
- Izmantojiet strukturētu formātu
- Skaidri sadaļu virsraksti
- Pilna informācija par pieredzi
- Konkrēti projekti un sasniegumiugums

❌ **DON'T:**
- Pārāk īss CV (< 500 vārdi)
- Haotisks formatējums
- Trūkstoša būtiska informācija

### 2. JD Rakstīšana

✅ **DO:**
- Skaidras, konkrētas prasības
- Atšķiriet obligātās un vēlamās
- Norādiet tehnisko steku
- Reālistiskas ekspektācijas

❌ **DON'T:**
- Pārāk vispārīgs apraksts
- Nereālistiskas prasības
- Neskaidras formulējumi

### 3. Rezultātu Izmantošana

✅ **DO:**
- Izmantojiet kā sākotnējo screening
- Kombinējiet ar manuālu pārbaudi
- Apsveriet kontekstu
- Salīdziniet vairākus kandidātus

❌ **DON'T:**
- Paļaujieties tikai uz AI
- Ignorējiet citus faktorus
- Pieņemiet lēmumus tikai pēc score

### 4. Workflow Optimizācija

1. **Sagatavošana:**
   - Kvalitātīvs JD
   - Strukturēti CV

2. **Batch Processing:**
   - Analizējiet visus vienlaicīgi
   - Izmantojiet web interfeisu

3. **Analīze:**
   - Salīdziniet kandidātus
   - Apskatiet detaļas

4. **Lēmums:**
   - Top 2-3 kandidāti
   - Aiciniet uz interviju

---

## 🎓 Noslēgums

Apsveicam! Jūs esat apguvis AI CV Vērtētāja lietošanu.

**Nākamie Soļi:**
1. Eksperimentējiet ar dažādiem CV
2. Pielāgojiet prompt savām vajadzībām
3. Integrējiet savā HR procesā

**Resursi:**
- 📖 [README.md](README.md) - Projekta overview
- 🚀 [QUICKSTART.md](QUICKSTART.md) - Ātrā sākšana
- 🔗 [Gemini API Docs](https://ai.google.dev/docs)

**Atbalsts:**
- Issues: GitHub repository
- Email: support@example.com

---

**Lai veiksmīgi ar AI CV Vērtētāju!** 🎉

*Izveidots ar ❤️ un Google Gemini Flash 2.5*
