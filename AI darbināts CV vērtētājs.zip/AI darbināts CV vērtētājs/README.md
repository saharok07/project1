# 🎯 AI Darbināts CV Vērtētājs

![Python](https://img.shields.io/badge/Python-3.8%2B-blue)
![Gemini](https://img.shields.io/badge/AI-Gemini%20Flash%202.5-orange)
![License](https://img.shields.io/badge/License-MIT-green)

## 📋 Projekta Apraksts

Profesionāla Python lietotne, kas izmanto **Google Gemini Flash 2.5** mākslīgā intelekta modeli, lai automātiski analizētu un salīdzinātu kandidātu CV ar darba aprakstu (Job Description). Sistema nodrošina detalizētu novērtējumu, identificē stiprās puses un trūkstošās prasmes, kā arī sniedz ieteikumu par kandidāta piemērotību.

## ✨ Galvenās Funkcijas

- 🤖 **AI analīze** - Izmanto Gemini Flash 2.5 precīzai CV novērtēšanai
- 📊 **Detalizēti pārskati** - JSON, Markdown un HTML formātos
- 🎨 **Moderns web interfeiss** - Profesionāls dizains ar animācijām
- 📈 **Match Score** - 0-100 atbilstības novērtējums
- 🔍 **Dziļa analīze** - Stiprās puses un trūkstošās prasmes
- 📚 **Vēsture** - Saglabā un ļauj skatīt iepriekšējās analīzes
- 🌐 **Daudzvalodu atbalsts** - Latviešu un starptautiskais formāts
- ⚡ **Ātrs un efektīvs** - Apstrādā visus CV sekundēs

## 🚀 Ātrā Sākšana

### Priekšnosacījumi

- Python 3.8 vai jaunāks
- Google Gemini API atslēga
- Interneta savienojums

### Instalācija

1. **Lejupielādējiet projektu**
   ```bash
   git clone <repository-url>
   cd AI_CV_Vertejums
   ```

2. **Izveidojiet virtuālo vidi (ieteicams)**
   ```bash
   python -m venv venv
   venv\Scripts\activate
   ```

3. **Instalējiet nepieciešamās bibliotēkas**
   ```bash
   pip install -r requirements.txt
   ```

4. **Konfigurējiet API atslēgu**
   
   Izveidojiet failu `.env` projekta saknē:
   ```
   GEMINI_API_KEY=jūsu_api_atslēga_šeit
   ```

### Izmantošana

#### Variants 1: Konsoles Versija

Vienkārši dubultklikšķiniet uz `KONSOLE.bat` vai izpildiet:
```bash
python main.py
```

#### Variants 2: Web Aplikācija (Ieteicams)

Dubultklikšķiniet uz `START.bat` vai izpildiet:
```bash
python app.py
```

Pēc tam atveriet pārlūkprogrammu: `http://localhost:5000`

### 💡 Vēstures Izmantošana

Skatīt iepriekšējās analīzes:
```batch
START_WITH_HISTORY.bat
```

Vai navigācijas izvēlnē noklikšķiniet uz **"Vēsture"**.

Sīkāka informācija: [VESTURE_INFO.md](VESTURE_INFO.md)

## 📁 Projekta Struktūra

```
AI_CV_Vertejums/
├── 📄 main.py              # Galvenais CLI skripts
├── 🌐 app.py               # Flask web aplikācija
├── 📝 prompt.md            # Gemini AI prompt veidne
├── 📋 requirements.txt     # Python atkarības
├── 🔧 .env                 # API konfigurācija
├── 📖 README.md            # Projekta dokumentācija
├── 🚀 QUICKSTART.md        # Ātrā pamācība
├── 👨‍🏫 INSTRUKCIJA.md       # Detalizēta instrukcija
├── 📚 VESTURE_INFO.md      # Vēstures funkcionalitāte
├── ✅ KONSOLE.bat          # Konsoles versijas palaišana
├── 🌐 START.bat            # Web versijas palaišana
├── 📜 START_WITH_HISTORY.bat # Palaist ar vēstures skatu
│
├── 📂 sample_inputs/       # Ievaddatu piemēri
│   ├── jd.txt             # Darba apraksts
│   ├── cv1.txt            # Kandidāts 1
│   ├── cv2.txt            # Kandidāts 2
│   └── cv3.txt            # Kandidāts 3
│
├── 📂 outputs/             # Rezultāti
│   ├── cv1.json           # JSON novērtējums
│   ├── cv1_report.md      # Markdown pārskats
│   ├── cv1_report.html    # HTML pārskats
│   └── ...
│
├── 📂 history/             # Analīžu vēsture
│   └── analysis_history.json # Vēstures datubāze
│
├── 📂 templates/           # HTML veidnes
│   ├── base.html
│   ├── index.html
│   ├── results.html
│   └── cv_detail.html
│
└── 📂 static/              # Statiskie resursi
    ├── css/
    │   └── styles.css     # Dizaina stili
    └── js/
        └── main.js        # JavaScript funkcionalitāte
```

## 🎯 Kā Tas Darbojas

1. **Ievaddatu nolasīšana** - Sistēma nolasa JD un CV failus
2. **AI analīze** - Gemini Flash 2.5 veic dziļu salīdzinājumu
3. **JSON ģenerēšana** - Strukturēts rezultāts ar vērtējumu
4. **Pārskatu veidošana** - Markdown un HTML formātā
5. **Vizualizācija** - Skaisti pārskati web saskarnē

## 📊 JSON Izvades Formāts

```json
{
  "match_score": 85,
  "summary": "Kandidāts labi atbilst pozīcijai ar spēcīgu tehnisko pieredzi.",
  "strengths": [
    "5+ gadu pieredze Python programmēšanā",
    "Pieredzējis darbā ar Flask un Django",
    "Teicamas problēmu risināšanas prasmes"
  ],
  "missing_requirements": [
    "Nav pieredzes ar React.js",
    "Trūkst DevOps zināšanu"
  ],
  "verdict": "strong match"
}
```

## 🎨 Web Interfeiss

- **Moderns dizains** - Profesionāls, tīrs izskats
- **Animācijas** - Smooth transitions un hover efekti
- **Responsīvs** - Darbojas uz visām ierīcēm
- **Interaktīvs** - Dinamiska satura ielāde
- **Vizuāli pārskati** - Krāsaini progresa bāri un ikonas

## 🔧 Konfigurācija

### Gemini API Iestatījumi

Rediģējiet `main.py` vai `app.py`:
```python
generation_config = {
    "temperature": 0.3,      # Precizitāte (0.0-1.0)
    "top_p": 0.95,
    "top_k": 40,
    "max_output_tokens": 8192,
}
```

### Temperature Iestatījumi

- **0.0-0.3** - Augsta precizitāte, konsekventas atbildes (ieteicams)
- **0.4-0.7** - Balansēts variants
- **0.8-1.0** - Radoša, bet neprecīza

## 📚 Papildu Resursi

- 📖 [QUICKSTART.md](QUICKSTART.md) - Ātrā sākšanas pamācība
- 👨‍🏫 [INSTRUKCIJA.md](INSTRUKCIJA.md) - Detalizēta instrukcija
- 🔍 [prompt.md](prompt.md) - AI prompt veidne
- ⚖️ [LICENSE](LICENSE) - MIT licence

## 🤝 Atbalsts

Ja rodas jautājumi vai problēmas:
1. Pārbaudiet, vai API atslēga ir pareiza
2. Pārliecinieties, ka visas bibliotēkas ir instalētas
3. Pārbaudiet, vai Python versija ir 3.8+
4. Lasiet INSTRUKCIJA.md detalizētai palīdzībai

## 📄 Licence

Šis projekts ir licencēts saskaņā ar MIT licenci - skatiet [LICENSE](LICENSE) failu.

## 🎓 Autors

Izstrādāts kā akadēmisks projekts, demonstrējot mākslīgā intelekta integrāciju HR procesos.

---

**⭐ Ja šis projekts jums palīdzēja, novērtējiet to ar zvaigznīti!**
