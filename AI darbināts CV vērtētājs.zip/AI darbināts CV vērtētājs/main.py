#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AI Darbināts CV Vērtētājs - Konsoles Versija
Izmanto Google Gemini Flash 2.5 modeli CV analīzei
"""

import os
import json
import google.generativeai as genai
from dotenv import load_dotenv
from pathlib import Path
import sys

# Krāsu kodi konsoles izvadei
class Colors:
    HEADER = '\033[95m'
    OKBLUE = '\033[94m'
    OKCYAN = '\033[96m'
    OKGREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

def print_header():
    """Izdrukā programmas galveni"""
    print(f"\n{Colors.HEADER}{Colors.BOLD}{'=' * 70}")
    print("  🤖 AI DARBINĀTS CV VĒRTĒTĀJS")
    print("  Powered by Google Gemini Flash 2.5")
    print(f"{'=' * 70}{Colors.ENDC}\n")

def load_file(filepath):
    """Nolasa teksta failu"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        print(f"{Colors.FAIL}❌ Fails nav atrasts: {filepath}{Colors.ENDC}")
        return None
    except Exception as e:
        print(f"{Colors.FAIL}❌ Kļūda nolasot failu: {e}{Colors.ENDC}")
        return None

def load_prompt_template():
    """Nolasa prompt veidni"""
    prompt_file = Path(__file__).parent / "prompt.md"
    template = load_file(prompt_file)
    if not template:
        print(f"{Colors.WARNING}⚠️  Izmanto noklusējuma prompt veidni{Colors.ENDC}")
        return get_default_prompt()
    return template

def get_default_prompt():
    """Atgriež noklusējuma prompt veidni"""
    return """Jūs esat profesionāls HR konsultants. Analizējiet kandidāta CV un salīdziniet to ar darba aprakstu.

Darba Apraksts:
{jd_text}

Kandidāta CV:
{cv_text}

Atbildiet TIKAI ar JSON formātu:
{{
  "match_score": <0-100>,
  "summary": "<īss apraksts latviski>",
  "strengths": ["<stiprā puse 1>", "<stiprā puse 2>", ...],
  "missing_requirements": ["<trūkstošā prasība 1>", ...],
  "verdict": "<strong match | possible match | not a match>"
}}
"""

def configure_gemini():
    """Konfigurē Gemini API"""
    load_dotenv()
    api_key = os.getenv('GEMINI_API_KEY')
    
    if not api_key:
        print(f"{Colors.FAIL}❌ KĻŪDA: GEMINI_API_KEY nav atrasts .env failā!{Colors.ENDC}")
        print(f"{Colors.WARNING}Lūdzu, izveidojiet .env failu un pievienojiet savu API atslēgu:{Colors.ENDC}")
        print(f"  GEMINI_API_KEY=jūsu_api_atslēga_šeit\n")
        sys.exit(1)
    
    genai.configure(api_key=api_key)
    return genai.GenerativeModel(
        model_name="gemini-2.0-flash-exp",
        generation_config={
            "temperature": 0.2,
            "top_p": 0.95,
            "top_k": 40,
            "max_output_tokens": 8192,
        }
    )

def analyze_cv(model, jd_text, cv_text, cv_name):
    """Analizē vienu CV ar Gemini API"""
    print(f"{Colors.OKCYAN}📄 Analizē: {cv_name}...{Colors.ENDC}")
    
    # Ielādē prompt veidni
    prompt_template = load_prompt_template()
    
    # Sagatavo pilnu prompt
    prompt = prompt_template.format(jd_text=jd_text, cv_text=cv_text)
    
    try:
        # Izsauc Gemini API
        response = model.generate_content(prompt)
        
        # Ekstraktē JSON no atbildes
        response_text = response.text.strip()
        
        # Noņem markdown code blocks, ja tādi ir
        if response_text.startswith("```json"):
            response_text = response_text[7:]
        if response_text.startswith("```"):
            response_text = response_text[3:]
        if response_text.endswith("```"):
            response_text = response_text[:-3]
        
        response_text = response_text.strip()
        
        # Parse JSON
        result = json.loads(response_text)
        
        print(f"{Colors.OKGREEN}✅ Analīze pabeigta!{Colors.ENDC}")
        return result
        
    except json.JSONDecodeError as e:
        print(f"{Colors.FAIL}❌ Kļūda parsējot JSON: {e}{Colors.ENDC}")
        print(f"{Colors.WARNING}API atbilde: {response.text[:500]}...{Colors.ENDC}")
        return None
    except Exception as e:
        print(f"{Colors.FAIL}❌ Kļūda analizējot CV: {e}{Colors.ENDC}")
        return None

def save_json_result(result, output_path):
    """Saglabā rezultātu JSON formātā"""
    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(f"{Colors.OKGREEN}💾 JSON saglabāts: {output_path}{Colors.ENDC}")
    except Exception as e:
        print(f"{Colors.FAIL}❌ Kļūda saglabājot JSON: {e}{Colors.ENDC}")

def generate_markdown_report(result, cv_name, output_path):
    """Ģenerē Markdown pārskatu"""
    match_score = result.get('match_score', 0)
    
    # Emoji atkarībā no vērtējuma
    if match_score >= 80:
        emoji = "🌟"
        level = "AUGSTS"
    elif match_score >= 50:
        emoji = "⚡"
        level = "VIDĒJS"
    else:
        emoji = "⚠️"
        level = "ZEMS"
    
    markdown = f"""# CV Novērtējuma Pārskats: {cv_name}

## {emoji} Atbilstības Rezultāts: {match_score}/100

**Līmenis:** {level}  
**Secinājums:** {result.get('verdict', 'nav noteikts').upper()}

---

## 📋 Kopsavilkums

{result.get('summary', 'Nav pieejams')}

---

## ✅ Stiprās Puses

"""
    
    strengths = result.get('strengths', [])
    for strength in strengths:
        markdown += f"- {strength}\n"
    
    markdown += "\n---\n\n## ❌ Trūkstošās Prasības\n\n"
    
    missing = result.get('missing_requirements', [])
    if missing:
        for req in missing:
            markdown += f"- {req}\n"
    else:
        markdown += "*Nav būtisku trūkumu*\n"
    
    markdown += f"\n---\n\n## 🎯 Galīgais Ieteikums\n\n"
    
    verdict = result.get('verdict', 'not a match')
    if verdict == "strong match":
        markdown += "**IETEICAMS** - Kandidāts ir piemērots pozīcijai. Aiciniet uz interviju.\n"
    elif verdict == "possible match":
        markdown += "**APSVĒRT** - Kandidāts atbilst daļai prasību. Papildu izvērtēšana nepieciešama.\n"
    else:
        markdown += "**NEIETEICAMS** - Kandidāts neatbilst galvenajām pozīcijas prasībām.\n"
    
    markdown += f"\n---\n*Ģenerēts ar AI CV Vērtētājs | Gemini Flash 2.5*\n"
    
    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(markdown)
        print(f"{Colors.OKGREEN}📝 Markdown pārskats saglabāts: {output_path}{Colors.ENDC}")
    except Exception as e:
        print(f"{Colors.FAIL}❌ Kļūda saglabājot Markdown: {e}{Colors.ENDC}")

def generate_html_report(result, cv_name, output_path):
    """Ģenerē HTML pārskatu"""
    match_score = result.get('match_score', 0)
    
    # Krāsa atkarībā no vērtējuma
    if match_score >= 80:
        color = "#10b981"
        emoji = "🌟"
    elif match_score >= 50:
        color = "#f59e0b"
        emoji = "⚡"
    else:
        color = "#ef4444"
        emoji = "⚠️"
    
    html = f"""<!DOCTYPE html>
<html lang="lv">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CV Novērtējums - {cv_name}</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            line-height: 1.6;
            color: #1f2937;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            min-height: 100vh;
        }}
        
        .container {{
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }}
        
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            text-align: center;
        }}
        
        .header h1 {{
            font-size: 2.5rem;
            margin-bottom: 10px;
        }}
        
        .header p {{
            opacity: 0.9;
            font-size: 1.1rem;
        }}
        
        .score-section {{
            text-align: center;
            padding: 50px 40px;
            background: #f9fafb;
        }}
        
        .score-circle {{
            width: 200px;
            height: 200px;
            margin: 0 auto 30px;
            border-radius: 50%;
            background: white;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            border: 10px solid {color};
        }}
        
        .score-number {{
            font-size: 4rem;
            font-weight: bold;
            color: {color};
        }}
        
        .score-label {{
            color: #6b7280;
            font-size: 1rem;
            margin-top: -10px;
        }}
        
        .verdict {{
            display: inline-block;
            padding: 12px 30px;
            background: {color};
            color: white;
            border-radius: 50px;
            font-weight: bold;
            font-size: 1.1rem;
            text-transform: uppercase;
        }}
        
        .content {{
            padding: 40px;
        }}
        
        .section {{
            margin-bottom: 40px;
        }}
        
        .section h2 {{
            font-size: 1.8rem;
            color: #1f2937;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 3px solid {color};
        }}
        
        .summary {{
            background: #f0fdf4;
            border-left: 4px solid #10b981;
            padding: 20px;
            border-radius: 8px;
            font-size: 1.1rem;
            line-height: 1.8;
        }}
        
        .list {{
            list-style: none;
        }}
        
        .list li {{
            padding: 15px;
            margin-bottom: 10px;
            background: #f9fafb;
            border-radius: 8px;
            border-left: 4px solid {color};
            transition: transform 0.2s, box-shadow 0.2s;
        }}
        
        .list li:hover {{
            transform: translateX(5px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }}
        
        .missing-list li {{
            border-left-color: #ef4444;
            background: #fef2f2;
        }}
        
        .footer {{
            background: #1f2937;
            color: white;
            padding: 30px;
            text-align: center;
        }}
        
        .footer p {{
            opacity: 0.8;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>{emoji} CV Novērtējuma Pārskats</h1>
            <p>{cv_name}</p>
        </div>
        
        <div class="score-section">
            <div class="score-circle">
                <div class="score-number">{match_score}</div>
                <div class="score-label">no 100</div>
            </div>
            <span class="verdict">{result.get('verdict', 'Nav noteikts').upper()}</span>
        </div>
        
        <div class="content">
            <div class="section">
                <h2>📋 Kopsavilkums</h2>
                <div class="summary">
                    {result.get('summary', 'Nav pieejams')}
                </div>
            </div>
            
            <div class="section">
                <h2>✅ Stiprās Puses</h2>
                <ul class="list">
"""
    
    for strength in result.get('strengths', []):
        html += f"                    <li>{strength}</li>\n"
    
    html += f"""                </ul>
            </div>
            
            <div class="section">
                <h2>❌ Trūkstošās Prasības</h2>
"""
    
    missing = result.get('missing_requirements', [])
    if missing:
        html += '                <ul class="list missing-list">\n'
        for req in missing:
            html += f"                    <li>{req}</li>\n"
        html += "                </ul>\n"
    else:
        html += '                <p style="color: #10b981; font-weight: bold;">Nav būtisku trūkumu</p>\n'
    
    html += """            </div>
        </div>
        
        <div class="footer">
            <p>Ģenerēts ar <strong>AI CV Vērtētājs</strong></p>
            <p>Powered by Google Gemini Flash 2.5</p>
        </div>
    </div>
</body>
</html>"""
    
    try:
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)
        print(f"{Colors.OKGREEN}🌐 HTML pārskats saglabāts: {output_path}{Colors.ENDC}")
    except Exception as e:
        print(f"{Colors.FAIL}❌ Kļūda saglabājot HTML: {e}{Colors.ENDC}")

def main():
    """Galvenā programmas funkcija"""
    print_header()
    
    # Direktorijas
    base_dir = Path(__file__).parent
    input_dir = base_dir / "sample_inputs"
    output_dir = base_dir / "outputs"
    
    # Izveido output direktoriju, ja tās nav
    output_dir.mkdir(exist_ok=True)
    
    # Nolasa JD
    jd_path = input_dir / "jd.txt"
    print(f"{Colors.OKBLUE}📖 Nolasa darba aprakstu...{Colors.ENDC}")
    jd_text = load_file(jd_path)
    
    if not jd_text:
        print(f"{Colors.FAIL}❌ Nevar turpināt bez darba apraksta!{Colors.ENDC}")
        sys.exit(1)
    
    print(f"{Colors.OKGREEN}✅ Darba apraksts nolasīts ({len(jd_text)} simboli){Colors.ENDC}\n")
    
    # Konfigurē Gemini
    print(f"{Colors.OKBLUE}🔧 Konfigurē Gemini API...{Colors.ENDC}")
    model = configure_gemini()
    print(f"{Colors.OKGREEN}✅ Gemini Flash 2.5 gatavs darbam!{Colors.ENDC}\n")
    
    # CV faili
    cv_files = [
        ("cv1.txt", "Kandidāts 1"),
        ("cv2.txt", "Kandidāts 2"),
        ("cv3.txt", "Kandidāts 3"),
    ]
    
    # Analizē katru CV
    for cv_file, cv_name in cv_files:
        print(f"\n{Colors.BOLD}{'─' * 70}{Colors.ENDC}")
        print(f"{Colors.HEADER}{Colors.BOLD}  Apstrādā: {cv_name}{Colors.ENDC}")
        print(f"{Colors.BOLD}{'─' * 70}{Colors.ENDC}\n")
        
        cv_path = input_dir / cv_file
        cv_text = load_file(cv_path)
        
        if not cv_text:
            print(f"{Colors.WARNING}⚠️  Izlaiž {cv_name}{Colors.ENDC}\n")
            continue
        
        print(f"{Colors.OKBLUE}📄 CV nolasīts ({len(cv_text)} simboli){Colors.ENDC}")
        
        # Analizē ar Gemini
        result = analyze_cv(model, jd_text, cv_text, cv_name)
        
        if result:
            # Failu nosaukumi
            cv_num = cv_file.replace('.txt', '')
            json_path = output_dir / f"{cv_num}.json"
            md_path = output_dir / f"{cv_num}_report.md"
            html_path = output_dir / f"{cv_num}_report.html"
            
            # Saglabā rezultātus
            save_json_result(result, json_path)
            generate_markdown_report(result, cv_name, md_path)
            generate_html_report(result, cv_name, html_path)
            
            print(f"\n{Colors.OKGREEN}{'✨' * 35}{Colors.ENDC}")
            print(f"{Colors.OKGREEN}  {cv_name} analīze pabeigta veiksmīgi!{Colors.ENDC}")
            print(f"{Colors.OKGREEN}{'✨' * 35}{Colors.ENDC}")
    
    # Noslēguma ziņojums
    print(f"\n\n{Colors.HEADER}{Colors.BOLD}{'═' * 70}")
    print("  ✅ VISI CV IR VEIKSMĪGI APSTRĀDĀTI!")
    print(f"{'═' * 70}{Colors.ENDC}\n")
    print(f"{Colors.OKCYAN}📁 Rezultāti saglabāti: {output_dir}{Colors.ENDC}")
    print(f"{Colors.OKCYAN}   - JSON faili: cvN.json{Colors.ENDC}")
    print(f"{Colors.OKCYAN}   - Markdown pārskati: cvN_report.md{Colors.ENDC}")
    print(f"{Colors.OKCYAN}   - HTML pārskati: cvN_report.html{Colors.ENDC}\n")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{Colors.WARNING}⚠️  Programma pārtraukta lietotāja pēc pieprasījuma{Colors.ENDC}\n")
        sys.exit(0)
    except Exception as e:
        print(f"\n{Colors.FAIL}❌ Neparedzēta kļūda: {e}{Colors.ENDC}\n")
        sys.exit(1)
