/**
 * AI CV Vērtētājs - Main JavaScript
 * Interactive functionality and animations
 */

// === Smooth Scrolling ===
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// === Navbar Scroll Effect ===
let lastScroll = 0;
const navbar = document.querySelector('.navbar');

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll > lastScroll && currentScroll > 100) {
        // Scrolling down
        navbar.style.transform = 'translateY(-100%)';
    } else {
        // Scrolling up
        navbar.style.transform = 'translateY(0)';
    }
    
    lastScroll = currentScroll;
});

// === Intersection Observer animācijām ===
const observerOptions = {
    root: null,
    rootMargin: '0px',
    threshold: 0.1
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('animate-in');
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Novērojam elementus animācijai
document.addEventListener('DOMContentLoaded', () => {
    const animatedElements = document.querySelectorAll(
        '.feature-card, .step, .result-card, .detail-card'
    );
    
    animatedElements.forEach(el => {
        el.classList.add('animate-ready');
        observer.observe(el);
    });
});

// === API Status Check ===
async function checkAPIStatus() {
    try {
        const response = await fetch('/api/status');
        const data = await response.json();
        
        if (data.status === 'ok') {
            console.log('✅ API Status: OK');
            console.log('Gemini API ir gatavs darbam');
        } else {
            console.warn('⚠️ API Status: Error');
            console.warn(data.message);
        }
    } catch (error) {
        console.error('❌ Nevar pārbaudīt API statusu:', error);
    }
}

// Pārbauda API statusu pie lapas ielādes
if (document.querySelector('.action-section')) {
    checkAPIStatus();
}

// === Toast Notifications ===
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    
    toast.style.cssText = `
        position: fixed;
        bottom: 20px;
        right: 20px;
        padding: 15px 25px;
        background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#667eea'};
        color: white;
        border-radius: 10px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        z-index: 10000;
        animation: slideInRight 0.5s ease-out;
        font-weight: 500;
    `;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
        toast.style.animation = 'slideOutRight 0.5s ease-out';
        setTimeout(() => toast.remove(), 500);
    }, 3000);
}

// === Utility Functions ===
function formatDate(date) {
    return new Date(date).toLocaleDateString('lv-LV', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

function formatScore(score) {
    if (score >= 80) return { class: 'high', label: 'Augsts' };
    if (score >= 50) return { class: 'medium', label: 'Vidējs' };
    return { class: 'low', label: 'Zems' };
}

// === Export Functions ===
function exportToJSON(data, filename) {
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    downloadBlob(blob, filename);
}

function downloadBlob(blob, filename) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
}

// === Progress Circle Animation ===
function animateProgressCircle(circle, score) {
    const circumference = 2 * Math.PI * 90; // r=90
    const progress = (score / 100) * circumference;
    
    circle.style.strokeDasharray = `${progress} ${circumference}`;
}

// Animējam visus progress circles lapā
document.addEventListener('DOMContentLoaded', () => {
    const progressCircles = document.querySelectorAll('.score-ring-progress');
    progressCircles.forEach(circle => {
        const scoreElement = circle.closest('.score-circle')?.querySelector('.score-number');
        if (scoreElement) {
            const score = parseInt(scoreElement.textContent);
            setTimeout(() => animateProgressCircle(circle, score), 300);
        }
    });
});

// === Copy to Clipboard ===
function copyToClipboard(text, successMessage = 'Nokopēts!') {
    navigator.clipboard.writeText(text).then(() => {
        showToast(successMessage, 'success');
    }).catch(err => {
        showToast('Kļūda kopējot', 'error');
        console.error('Copy failed:', err);
    });
}

// === Print Page ===
function printPage() {
    window.print();
}

// === Dark Mode Toggle (bonus feature) ===
function initDarkMode() {
    const darkModeToggle = document.getElementById('darkModeToggle');
    if (!darkModeToggle) return;
    
    const isDark = localStorage.getItem('darkMode') === 'true';
    if (isDark) {
        document.body.classList.add('dark-mode');
    }
    
    darkModeToggle.addEventListener('click', () => {
        document.body.classList.toggle('dark-mode');
        const isDarkNow = document.body.classList.contains('dark-mode');
        localStorage.setItem('darkMode', isDarkNow);
        showToast(isDarkNow ? 'Tumšais režīms ieslēgts' : 'Gaišais režīms ieslēgts', 'info');
    });
}

document.addEventListener('DOMContentLoaded', initDarkMode);

// === Add Loading States ===
function setLoadingState(button, isLoading) {
    if (isLoading) {
        button.dataset.originalText = button.innerHTML;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Apstrādā...';
        button.disabled = true;
    } else {
        button.innerHTML = button.dataset.originalText || button.innerHTML;
        button.disabled = false;
    }
}

// === Form Validation ===
function validateForm(form) {
    const inputs = form.querySelectorAll('input[required], textarea[required]');
    let isValid = true;
    
    inputs.forEach(input => {
        if (!input.value.trim()) {
            input.classList.add('error');
            isValid = false;
        } else {
            input.classList.remove('error');
        }
    });
    
    return isValid;
}

// === Keyboard Shortcuts ===
document.addEventListener('keydown', (e) => {
    // Ctrl/Cmd + K - Fokuss uz meklēšanu
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        const searchInput = document.querySelector('input[type="search"]');
        if (searchInput) searchInput.focus();
    }
    
    // Esc - Aizvērt modāļus
    if (e.key === 'Escape') {
        const modals = document.querySelectorAll('.modal.active');
        modals.forEach(modal => modal.classList.remove('active'));
    }
});

// === Lazy Loading Images ===
if ('IntersectionObserver' in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.classList.remove('lazy');
                observer.unobserve(img);
            }
        });
    });
    
    document.querySelectorAll('img.lazy').forEach(img => {
        imageObserver.observe(img);
    });
}

// === Performance Monitoring ===
if ('performance' in window) {
    window.addEventListener('load', () => {
        const perfData = performance.timing;
        const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart;
        console.log(`📊 Lapas ielādes laiks: ${pageLoadTime}ms`);
    });
}

// === Error Handling ===
window.addEventListener('error', (e) => {
    console.error('JavaScript Error:', e.message);
    // Var pievienot kļūdu ziņošanas servisu
});

window.addEventListener('unhandledrejection', (e) => {
    console.error('Unhandled Promise Rejection:', e.reason);
});

// === Console Message ===
console.log('%c🤖 AI CV Vērtētājs', 'font-size: 20px; font-weight: bold; color: #667eea;');
console.log('%cPowered by Google Gemini Flash 2.5', 'font-size: 12px; color: #6b7280;');
console.log('%c\nPieejamie API endpoints:', 'font-weight: bold;');
console.log('  GET  /api/status - API statusa pārbaude');
console.log('  POST /analyze - CV analīze');
console.log('  GET  /cv/<id> - Detalizēts pārskats');

// Export functions for global use
window.CVApp = {
    showToast,
    copyToClipboard,
    exportToJSON,
    formatDate,
    formatScore,
    setLoadingState,
    validateForm
};
