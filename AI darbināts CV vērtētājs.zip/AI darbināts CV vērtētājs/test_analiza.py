# -*- coding: utf-8 -*-
"""
ANALĪZES TESTS - Darba pārbaude bez Flask
"""
import sys
import os
from pathlib import Path
import json

# Pievienojam ceļu uz projektu
current_dir = Path(__file__).parent
sys.path.insert(0, str(current_dir))

print("="*70)
print("🧪 CV ANALĪZES TESTS (BEZ FLASK)")
print("="*70)

# Importi
try:
    import google.generativeai as genai
    from dotenv import load_dotenv
    print("✅ Bibliotēkas importētas")
except ImportError as e:
    print(f"❌ Importa kļūda: {e}")
    input("Nospiediet Enter...")
    sys.exit(1)

# Ielādē .env
load_dotenv()
api_key = os.getenv('GEMINI_API_KEY')

if not api_key:
    print("❌ API atslēga nav atrasta .env failā!")
    input("Nospiediet Enter...")
    sys.exit(1)

print(f"✅ API atslēga ielādēta: {api_key[:10]}...{api_key[-5:]}")

# Gemini konfigurācija
try:
    genai.configure(api_key=api_key)
    model = genai.GenerativeModel(
        'gemini-2.0-flash-exp',
        generation_config={'temperature': 0.2}
    )
    print("✅ Gemini modelis konfigurēts")
except Exception as e:
    print(f"❌ Gemini konfigurācijas kļūda: {e}")
    input("Nospiediet Enter...")
    sys.exit(1)

# Failu ielāde
print("\n📁 Failu ielāde...")

jd_file = current_dir / "sample_inputs" / "jd.txt"
cv1_file = current_dir / "sample_inputs" / "cv1.txt"

if not jd_file.exists():
    print(f"❌ Fails nav atrasts: {jd_file}")
    input("Nospiediet Enter...")
    sys.exit(1)

if not cv1_file.exists():
    print(f"❌ Fails nav atrasts: {cv1_file}")
    input("Nospiediet Enter...")
    sys.exit(1)

with open(jd_file, 'r', encoding='utf-8') as f:
    jd_text = f.read()
    print(f"✅ JD ielādēts: {len(jd_text)} simboli")

with open(cv1_file, 'r', encoding='utf-8') as f:
    cv_text = f.read()
    print(f"✅ CV1 ielādēts: {len(cv_text)} simboli")

# Prompt ielāde
prompt_file = current_dir / "prompt.md"
if prompt_file.exists():
    with open(prompt_file, 'r', encoding='utf-8') as f:
        prompt_template = f.read()
    print(f"✅ Prompt ielādēts: {len(prompt_template)} simboli")
else:
    print("⚠️  prompt.md nav atrasts, izmantoju pamata prompt")
    prompt_template = """Jūs esat profesionāls HR konsultants. Analizējiet kandidāta CV un salīdziniet to ar darba aprakstu.

Darba Apraksts:
{jd_text}

Kandidāta CV:
{cv_text}

Atbildiet TIKAI ar JSON formātu:
{{
  "match_score": <0-100>,
  "summary": "<īss apraksts latviski>",
  "strengths": ["<stiprā puse 1>", "<stiprā puse 2>", ...],
  "missing_requirements": ["<trūkstošā prasība 1>", ...],
  "verdict": "<strong match | possible match | not a match>"
}}
"""

# Veidojam prompt
prompt = prompt_template.format(jd_text=jd_text, cv_text=cv_text)
print(f"\n🤖 Sūta pieprasījumu uz Gemini API...")
print(f"📊 Prompt izmērs: {len(prompt)} simboli")

try:
    response = model.generate_content(prompt)
    response_text = response.text.strip()
    
    print(f"\n✅ Saņemta atbilde no Gemini!")
    print(f"📏 Atbildes izmērs: {len(response_text)} simboli")
    
    # Rādām pirmos 200 simbolus
    print(f"\n📝 Pirmie 200 atbildes simboli:")
    print("-" * 70)
    print(response_text[:200])
    print("-" * 70)
    
    # Mēģinām parsēt JSON
    print(f"\n🔍 JSON parsēšana...")
    
    # Noņemam markdown blokus
    if response_text.startswith("```json"):
        response_text = response_text[7:]
    if response_text.startswith("```"):
        response_text = response_text[3:]
    if response_text.endswith("```"):
        response_text = response_text[:-3]
    
    response_text = response_text.strip()
    
    result = json.loads(response_text)
    
    print("✅ JSON veiksmīgi parsēts!")
    print("\n" + "="*70)
    print("ANALĪZES REZULTĀTS:")
    print("="*70)
    print(f"📊 Match Score: {result.get('match_score', 'N/A')}/100")
    print(f"📝 Kopsavilkums: {result.get('summary', 'N/A')[:100]}...")
    print(f"✅ Stiprās puses: {len(result.get('strengths', []))} punkti")
    print(f"⚠️  Trūkstošais: {len(result.get('missing_requirements', []))} punkti")
    print(f"🎯 Secinājums: {result.get('verdict', 'N/A')}")
    print("="*70)
    
    # Saglabājam failā
    output_file = current_dir / "test_result.json"
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    print(f"\n💾 Rezultāts saglabāts: {output_file}")
    print("\n✅ VISS DARBOJAS! ANALĪZE VEIKSMĪGI PABEIGTA!")
    
except json.JSONDecodeError as e:
    print(f"\n❌ JSON parsēšanas kļūda: {e}")
    print(f"\n📝 Pilna atbilde no Gemini:")
    print("-" * 70)
    print(response_text)
    print("-" * 70)
    
except Exception as e:
    print(f"\n❌ Kļūda: {e}")
    import traceback
    traceback.print_exc()

print("\n" + "="*70)
input("\nNospiediet Enter, lai izietu...")
